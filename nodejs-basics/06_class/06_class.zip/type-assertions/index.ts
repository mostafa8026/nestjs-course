let message;
message = "adsadfsd";
const m = (message as string).startsWith("a");
console.log(m);
